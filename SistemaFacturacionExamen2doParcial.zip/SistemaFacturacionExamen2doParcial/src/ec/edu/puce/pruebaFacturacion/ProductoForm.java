package ec.edu.puce.pruebaFacturacion;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ProductoForm extends JInternalFrame {

    private static final long serialVersionUID = 1L;
    private JTextField txtIdProducto, txtDescripcion, txtPrecio, txtCantidad;
    private JButton btnGuardar;
    private JTable table;
    private DefaultTableModel model;
    private static ArrayList<Producto> productos = new ArrayList<>();

    public ProductoForm() {
        setTitle("Agregar Productos");
        setBounds(100, 100, 450, 500);
        getContentPane().setLayout(null);

        initLabels();
        initTextFields();
        initButtons();
        initTable();
    }

    private void initLabels() {
        createLabel("Id", 39, 26, 118, 14);
        createLabel("Descripción", 39, 65, 88, 14);
        createLabel("Precio", 39, 104, 88, 14);
        createLabel("Cantidad", 39, 143, 88, 14);
    }

    private void createLabel(String text, int x, int y, int width, int height) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label.setBounds(x, y, width, height);
        getContentPane().add(label);
    }

    private void initTextFields() {
        txtIdProducto = createTextField(119, 25, 260, 20);
        txtDescripcion = createTextField(119, 64, 260, 20);
        txtPrecio = createTextField(119, 103, 260, 20);
        txtCantidad = createTextField(119, 142, 260, 20);
    }

    private JTextField createTextField(int x, int y, int width, int height) {
        JTextField textField = new JTextField();
        textField.setBounds(x, y, width, height);
        getContentPane().add(textField);
        return textField;
    }

    private void initButtons() {
        createButton("Nuevo", 45, 190, 90, 23, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });

        btnGuardar = createButton("Guardar", 180, 190, 90, 23, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                crearProducto();
            }
        });

        createButton("Cancelar", 315, 190, 89, 23, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        });
    }

    private JButton createButton(String label, int x, int y, int width, int height, ActionListener actionListener) {
        JButton button = new JButton(label);
        button.addActionListener(actionListener);
        button.setBounds(x, y, width, height);
        getContentPane().add(button);
        return button;
    }

    private void initTable() {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(45, 224, 359, 218);
        getContentPane().add(scrollPane);

        table = new JTable();
        table.setBackground(new Color(192, 192, 192));
        table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Id", "Descripción", "Precio", "Cantidad", "Total" }));
        scrollPane.setViewportView(table);
        model = (DefaultTableModel) table.getModel();
    }

    private void limpiarCampos() {
        txtIdProducto.setText("");
        txtDescripcion.setText("");
        txtPrecio.setText("");
        txtCantidad.setText("");
    }

    private void cerrarVentana() {
        setVisible(false);
    }

    private void crearProducto() {
        Producto producto = new Producto(txtIdProducto.getText(), txtDescripcion.getText(),
                Double.parseDouble(txtPrecio.getText()), Integer.parseInt(txtCantidad.getText()));
        productos.add(producto);
        agregarFila();
    }

    private void agregarFila() {
        Object[] fila = new Object[5];
        Producto ultimoProducto = productos.get(productos.size() - 1);
        fila[0] = ultimoProducto.getIdProducto();
        fila[1] = ultimoProducto.getDescripcion();
        fila[2] = ultimoProducto.getPrecio();
        fila[3] = ultimoProducto.getCantidad();
        fila[4] = ultimoProducto.getTotal();
        model.addRow(fila);
    }

    public static ArrayList<Producto> getProductos() {
        return productos;
    }
}
