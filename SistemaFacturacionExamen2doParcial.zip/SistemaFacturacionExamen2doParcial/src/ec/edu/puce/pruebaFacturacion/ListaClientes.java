package ec.edu.puce.pruebaFacturacion;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class ListaClientes extends JDialog {

    private static final long serialVersionUID = 1L;
    private final JPanel contentPanel = new JPanel();
    private JTable table;
    private DefaultTableModel model;
    private int indiceCliente = -1;

    public ListaClientes(Dialog owner, boolean modal, JLabel lblCedula, JLabel lblNombres, JLabel lblApellidos,
            JLabel lblTelefono, JLabel lblEmail, JLabel lblDireccion) {
        super(owner, modal);
        setBounds(100, 100, 572, 300);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(null);

        initTable();
        initButtons(lblCedula, lblNombres, lblApellidos, lblTelefono, lblEmail, lblDireccion);
    }

    private void initTable() {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 11, 416, 208);
        contentPanel.add(scrollPane);

        table = new JTable();
        table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Cedula", "Nombres", "Apellidos", "Teléfono", "Email", "Dirección" }));
        scrollPane.setViewportView(table);
        model = (DefaultTableModel) table.getModel();

        if (!ClienteForm.getClientes().isEmpty()) {
            agregarClientes();
        }
    }

    private void agregarClientes() {
        ArrayList<Cliente> clientes = new ArrayList<>(ClienteForm.getClientes());

        for (Cliente cliente : clientes) {
            Object[] fila = new Object[6];
            fila[0] = cliente.getCedula();
            fila[1] = cliente.getNombres();
            fila[2] = cliente.getApellidos();
            fila[3] = cliente.getTelefono();
            fila[4] = cliente.getEmail();
            fila[5] = cliente.getDireccion();
            this.model.addRow(fila);

            JButton btnCliente = new JButton("Elegir");
            btnCliente.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    seleccionarCliente(clientes.indexOf(cliente));
                }
            });
            btnCliente.setBounds(440, 30 + (clientes.indexOf(cliente) * 18), 89, 17);
            contentPanel.add(btnCliente);
        }
    }

    private void seleccionarCliente(int i) {
        this.indiceCliente = i;
    }

    private void initButtons(JLabel lblCedula, JLabel lblNombres, JLabel lblApellidos, JLabel lblTelefono,
            JLabel lblEmail, JLabel lblDireccion) {
        JPanel buttonPane = new JPanel();
        buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
        getContentPane().add(buttonPane, BorderLayout.SOUTH);

        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                enviarCliente(lblCedula, lblNombres, lblApellidos, lblTelefono, lblEmail, lblDireccion);
            }
        });
        okButton.setActionCommand("OK");
        buttonPane.add(okButton);
        getRootPane().setDefaultButton(okButton);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        cancelButton.setActionCommand("Cancel");
        buttonPane.add(cancelButton);
    }

    private void enviarCliente(JLabel lblCedula, JLabel lblNombres, JLabel lblApellidos, JLabel lblTelefono,
            JLabel lblEmail, JLabel lblDireccion) {
        if (this.indiceCliente == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione un cliente", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Cliente clienteSeleccionado = ClienteForm.getClientes().get(indiceCliente);
        lblCedula.setText("Cédula: " + clienteSeleccionado.getCedula());
        lblNombres.setText("Nombres: " + clienteSeleccionado.getNombres());
        lblApellidos.setText("Apellidos: " + clienteSeleccionado.getApellidos());
        lblTelefono.setText("Teléfono: " + clienteSeleccionado.getTelefono());
        lblEmail.setText("Email: " + clienteSeleccionado.getEmail());
        lblDireccion.setText("Dirección: " + clienteSeleccionado.getDireccion());
        dispose();
    }
}
