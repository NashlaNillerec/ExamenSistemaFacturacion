package ec.edu.puce.pruebaFacturacion;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Random;

public class FacturaForm extends JInternalFrame {

    private static final long serialVersionUID = 1L;
    private JLabel fCedula, fNombres, fApellidos, fTelfono, fEmail, fDireccin, fIVA, fTotal, fSubtotal, lblNumeroFactura;
    private JTable table;
    private DefaultTableModel model;
    private ArrayList<Producto> productos = new ArrayList<>();

    public FacturaForm() {
        setTitle("Factura");
        setBounds(100, 100, 590, 498);
        getContentPane().setLayout(null);

        initClienteLabels();
        initClienteButton();
        initButtons();
        initTable();
        initTotalLabels();
        initNumeroFacturaLabel();
    }

    private void initClienteLabels() {
        fCedula = createLabel("Cédula/RUC:", 37, 53);
        fNombres = createLabel("Nombres:", 37, 73);
        fApellidos = createLabel("Apellidos:", 37, 93);
        fTelfono = createLabel("Teléfono:", 37, 113);
        fEmail = createLabel("Email:", 37, 133);
        fDireccin = createLabel("Dirección:", 306, 127);

        JLabel lblFecha = new JLabel("Fecha: " + obtenerFechaActual());
        lblFecha.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblFecha.setBounds(306, 40, 120, 20);
        getContentPane().add(lblFecha);
    }

    private JLabel createLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label.setBounds(x, y, 242, 27);
        getContentPane().add(label);
        return label;
    }

    private void initClienteButton() {
        JButton btnSeleccionarCliente = new JButton("🔎 Buscar cliente");
        btnSeleccionarCliente.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pedirDatos();
            }
        });
        btnSeleccionarCliente.setBounds(306, 70, 145, 28);
        getContentPane().add(btnSeleccionarCliente);
    }

    private void initButtons() {
        createButton("🚫 Cancelar", 37, 410, 110, 23, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        createButton("✖️ Quitar", 447, 165, 100, 23, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                eliminarProducto();
            }
        });

        createButton("✔️ Añadir", 340, 165, 100, 23, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                agregarProducto();
            }
        });

        createButton("➕ Nuevo", 37, 11, 100, 30, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirDeNuevo();
            }
        });

        createButton("🔙 Limpiar", 150, 11, 100, 30, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                limpiarYGenerarNumeroFactura();
            }
        });
    }

    private void createButton(String label, int x, int y, int width, int height, ActionListener actionListener) {
        JButton button = new JButton(label);
        button.addActionListener(actionListener);
        button.setBounds(x, y, width, height);
        getContentPane().add(button);
    }

    private void initTable() {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(37, 191, 511, 141);
        getContentPane().add(scrollPane);

        table = new JTable();
        table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Id", "Descripción", "Precio", "Cantidad", "Total" }));
        scrollPane.setViewportView(table);
        model = (DefaultTableModel) table.getModel();
    }

    private void initTotalLabels() {
        fSubtotal = createLabel("Subtotal:", 420, 343);
        fIVA = createLabel("IVA:", 448, 368);
        fTotal = createLabel("Total:", 438, 393);
    }

    private void initNumeroFacturaLabel() {
        lblNumeroFactura = createLabel("Número Factura:", 306, 11);
    }

    private void pedirDatos() {
        ListaClientes listaCliente = new ListaClientes(new JDialog(), true, fCedula, fNombres, fApellidos, fTelfono, fEmail, fDireccin);
        listaCliente.setVisible(true);
    }

    private void agregarProducto() {
        ListaProductos listaProductos = new ListaProductos(new JDialog(), true, model, productos, fSubtotal, fIVA, fTotal);
        listaProductos.setVisible(true);
    }

    private void eliminarProducto() {
        EliminarProducto eliminarProducto = new EliminarProducto(new JDialog(), true, model, productos, fSubtotal, fIVA, fTotal);
        eliminarProducto.setVisible(true);
    }

    private void abrirDeNuevo() {
        Container menuPrincipal = getParent();
        dispose();
        FacturaForm frmFacturar = new FacturaForm();
        frmFacturar.setVisible(true);
        menuPrincipal.add(frmFacturar);
    }

    private void limpiarYGenerarNumeroFactura() {
        model.setRowCount(0);  
        fCedula.setText("");
        fNombres.setText("");
        fApellidos.setText("");
        fTelfono.setText("");
        fEmail.setText("");
        fDireccin.setText("");
        generarNumeroFactura();
    }

    private void generarNumeroFactura() {
        Random rand = new Random();
        int numeroFactura = rand.nextInt(10000) + 1;
        lblNumeroFactura.setText("Número Factura: " + numeroFactura);
    }

    private String obtenerFechaActual() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date(System.currentTimeMillis());
        return dateFormat.format(date);
    }
}
