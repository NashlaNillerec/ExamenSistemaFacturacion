package ec.edu.puce.pruebaFacturacion;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class EliminarProducto extends JDialog {

    private static final long serialVersionUID = 1L;
    private final JPanel contentPanel = new JPanel();
    private DefaultTableModel modelLocal;
    private JTable table;
    private int indiceProducto = -1;

    public EliminarProducto(Dialog owner, boolean modal, DefaultTableModel model, ArrayList<Producto> productos,
            JLabel lblSubtotal, JLabel lblIVA, JLabel lblTotal) {
        super(owner, modal);
        setBounds(100, 100, 481, 300);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(new BorderLayout(0, 0));

        JScrollPane scrollPane = new JScrollPane();
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        table = new JTable();
        table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Id", "Descripción", "Precio", "Cantidad", "Total" }));
        scrollPane.setViewportView(table);
        modelLocal = (DefaultTableModel) table.getModel();

        if (!productos.isEmpty()) {
            agregarProducto(productos);
        }

        JPanel buttonPane = new JPanel();
        buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
        getContentPane().add(buttonPane, BorderLayout.SOUTH);

        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                eliminarProducto(model, productos, lblSubtotal, lblIVA, lblTotal);
            }
        });
        buttonPane.add(okButton);
        getRootPane().setDefaultButton(okButton);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        buttonPane.add(cancelButton);
    }

    private void agregarProducto(ArrayList<Producto> productos) {
        for (Producto producto : productos) {
            Object[] fila = { producto.getIdProducto(), producto.getDescripcion(), producto.getPrecio(),
                    producto.getCantidad(), producto.getTotal() };
            modelLocal.addRow(fila);

            JButton btnProducto = new JButton("Elegir");
            btnProducto.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    seleccionarProducto(productos.indexOf(producto));
                }
            });
            contentPanel.add(btnProducto, BorderLayout.EAST);
        }
    }

    private void seleccionarProducto(int i) {
        this.indiceProducto = i;
    }

    private void eliminarProducto(DefaultTableModel model, ArrayList<Producto> productos, JLabel lblSubtotal,
            JLabel lblIVA, JLabel lblTotal) {
        if (this.indiceProducto == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione un producto", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        model.removeRow(indiceProducto);

        Producto productoSeleccionado = productos.get(indiceProducto);
        for (Producto producto : ProductoForm.getProductos()) {
            if (producto.getIdProducto() == productoSeleccionado.getIdProducto()) {
                producto.setCantidad(producto.getCantidad() + productoSeleccionado.getCantidad());
            }
        }

        productos.remove(indiceProducto);

        double total = calcularTotal(productos);
        double iva = total * 0.12;
        lblSubtotal.setText("Subtotal: " + total);
        lblIVA.setText("IVA: " + String.format("%.2f", iva));
        lblTotal.setText("Total: " + (total + iva));
        dispose();
    }

    private double calcularTotal(ArrayList<Producto> productos) {
        double total = 0;
        for (Producto producto : productos) {
            total += producto.getTotal();
        }
        return total;
    }
}
