package ec.edu.puce.pruebaFacturacion;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ClienteForm extends JInternalFrame {

    private static final long serialVersionUID = 1L;
    private JTextField txtCedula;
    private JTextField txtNombres;
    private JTextField txtApellidos;
    private JTextField txtTelefono;
    private JTextField txtEmail;
    private JTextField txtDireccion;
    private JButton btnGuardar;
    private JTable table;
    private DefaultTableModel model;
    private static ArrayList<Cliente> clientes = new ArrayList<>();

    public ClienteForm() {
        setTitle("Agregar Clientes");
        setBounds(100, 100, 450, 500);
        getContentPane().setLayout(null);

        initLabels();
        initTextFields();
        initButtons();
        initTable();
    }

    private void initLabels() {
        String[] labels = { "Cédula", "Nombres", "Apellidos", "Teléfono", "Email", "Dirección" };
        int y = 26;
        for (String label : labels) {
            JLabel lbl = new JLabel(label);
            lbl.setFont(new Font("Tahoma", Font.PLAIN, 15));
            lbl.setBounds(39, y, 103, 14);
            getContentPane().add(lbl);
            y += 39; // Incremento de acuerdo a la posición y de cada label
        }
    }

    private void initTextFields() {
        txtCedula = createTextField(119, 25);
        txtNombres = createTextField(119, 64);
        txtApellidos = createTextField(119, 103);
        txtTelefono = createTextField(119, 142);
        txtEmail = createTextField(119, 181);
        txtDireccion = createTextField(119, 220);
    }

    private JTextField createTextField(int x, int y) {
        JTextField textField = new JTextField();
        textField.setColumns(10);
        textField.setBounds(x, y, 260, 20);
        getContentPane().add(textField);
        return textField;
    }

    private void initButtons() {
        btnGuardar = createButton("Guardar", 180, 274, 90, 23, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                crearCliente();
            }
        });

        createButton("Nuevo", 45, 274, 90, 23, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });

        createButton("Cancelar", 315, 274, 89, 23, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        });
    }

    private JButton createButton(String label, int x, int y, int width, int height, ActionListener actionListener) {
        JButton button = new JButton(label);
        button.addActionListener(actionListener);
        button.setBounds(x, y, width, height);
        getContentPane().add(button);
        return button;
    }

    private void initTable() {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(45, 308, 359, 140);
        getContentPane().add(scrollPane);

        table = new JTable();
        table.setBackground(new Color(192, 192, 192));
        table.setModel(new DefaultTableModel(new Object[][] {},
                new String[] { "Cédula", "Nombres", "Apellidos", "Teléfono", "Email", "Dirección" }));
        scrollPane.setViewportView(table);
        model = (DefaultTableModel) table.getModel();
    }

    private void limpiarCampos() {
        JTextField[] textFields = { txtCedula, txtNombres, txtApellidos, txtTelefono, txtEmail, txtDireccion };
        for (JTextField textField : textFields) {
            textField.setText("");
        }
    }

    private void cerrarVentana() {
        this.setVisible(false);
    }

    private void crearCliente() {
        Cliente cliente = new Cliente(txtCedula.getText(), txtNombres.getText(), txtApellidos.getText(),
                txtTelefono.getText(), txtEmail.getText(), txtDireccion.getText());
        clientes.add(cliente);
        agregarFila();
    }

    private void agregarFila() {
        Object[] fila = new Object[6];
        Cliente ultimoCliente = clientes.get(clientes.size() - 1);
        fila[0] = ultimoCliente.getCedula();
        fila[1] = ultimoCliente.getNombres();
        fila[2] = ultimoCliente.getApellidos();
        fila[3] = ultimoCliente.getTelefono();
        fila[4] = ultimoCliente.getEmail();
        fila[5] = ultimoCliente.getDireccion();
        model.addRow(fila);
    }

    public static ArrayList<Cliente> getClientes() {
        return clientes;
    }
}
