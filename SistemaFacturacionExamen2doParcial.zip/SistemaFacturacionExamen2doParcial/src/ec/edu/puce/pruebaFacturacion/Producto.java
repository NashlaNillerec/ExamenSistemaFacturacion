package ec.edu.puce.pruebaFacturacion;

public class Producto {
    private String idProducto;
    private String descripcion;
    private double precio;
    private int cantidad;
    private double total;

    public Producto(String idProducto, String descripcion, double precio, int cantidad) {
        this.idProducto = idProducto;
        this.descripcion = descripcion;
        this.setPrecio(precio); // Validación de precio no negativo
        this.setCantidad(cantidad); // Validación de cantidad no negativa
        this.calcularTotal();
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if (precio < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }
        this.precio = precio;
        this.calcularTotal();
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        if (cantidad < 0) {
            throw new IllegalArgumentException("La cantidad no puede ser negativa");
        }
        this.cantidad = cantidad;
        this.calcularTotal();
    }

    public double getTotal() {
        return total;
    }

    private void calcularTotal() {
        this.total = this.precio * this.cantidad;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "idProducto='" + idProducto + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", precio=" + precio +
                ", cantidad=" + cantidad +
                ", total=" + total +
                '}';
    }
}
